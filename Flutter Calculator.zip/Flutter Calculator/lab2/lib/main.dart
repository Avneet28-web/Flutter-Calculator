import 'package:flutter/material.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Scientific Calculator',
      theme: ThemeData.dark().copyWith(
        colorScheme: const ColorScheme.dark(
          primary: Colors.tealAccent,
          secondary: Colors.orangeAccent,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

// Splash Screen
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const CalculatorScreen()),
      );
    });

    return Scaffold(
      backgroundColor: Colors.blueAccent,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              'assets/logo.jpg', // Ensure this matches your asset path
              width: 200,
              height: 200,
            ),
            const SizedBox(height: 20),
            const Text(
              'Welcome to Calculator',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Calculator Screen
class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _output = "0";
  String _operand = "";
  double _firstOperand = 0;
  double _secondOperand = 0;

  void _buttonPressed(String value) {
    setState(() {
      if (value == "C") {
        _output = "0";
        _operand = "";
        _firstOperand = 0;
        _secondOperand = 0;
      } else if (value == "+" || value == "-" || value == "*" || value == "/") {
        _operand = value;
        _firstOperand = double.parse(_output);
        _output = "0";
      } else if (value == "=") {
        _secondOperand = double.parse(_output);
        switch (_operand) {
          case "+":
            _output = (_firstOperand + _secondOperand).toString();
            break;
          case "-":
            _output = (_firstOperand - _secondOperand).toString();
            break;
          case "*":
            _output = (_firstOperand * _secondOperand).toString();
            break;
          case "/":
            _output = _secondOperand != 0
                ? (_firstOperand / _secondOperand).toString()
                : "Error";
            break;
          default:
            _output = "0";
        }
        _operand = "";
      } else {
        _output = _output == "0" ? value : _output + value;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Scientific Calculator"),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Display
          Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.all(20),
            child: Text(
              _output,
              style: const TextStyle(
                fontSize: 60,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
          // Buttons
          Column(
            children: [
              _buildButtonRow(["7", "8", "9", "/"], Colors.orange),
              _buildButtonRow(["4", "5", "6", "*"], Colors.green),
              _buildButtonRow(["1", "2", "3", "-"], Colors.blue),
              _buildButtonRow(["C", "0", "=", "+"], Colors.red),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildButtonRow(List<String> values, Color buttonColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: values.map((value) {
        return ElevatedButton(
          onPressed: () => _buttonPressed(value),
          style: ElevatedButton.styleFrom(
            shape: const CircleBorder(),
            padding: const EdgeInsets.all(20),
            backgroundColor: buttonColor,
            elevation: 8,
            shadowColor: Colors.black54,
            foregroundColor: Colors.white,
            minimumSize: const Size(70, 70),
          ),
          child: Text(
            value,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
        );
      }).toList(),
    );
  }
}
